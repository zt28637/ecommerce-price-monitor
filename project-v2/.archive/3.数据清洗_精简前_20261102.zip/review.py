"""人工复核单：生成 / 应用。JSON 为主，日报 Excel 提供人读列。

review_result.json 结构：
{
  "date": "2026-11-01",
  "generated_at": "...",
  "policy": {"sample_ratio": 0.05, "rule": "入库只消费 auto_pass / approved"},
  "decisions": {
    "item": {"<product_id>": {"status": "", "note": "", "reviewer": ""}},
    "sku":  {"<sku_id>":     {"status": "", "note": "", "reviewer": ""}}
  },
  "summary": {...}
}

status 只填 approved / rejected；留空 = 尚未复核。
应用后：approved -> review_status=approved；rejected -> rejected（保留在 *_reviewed.jsonl 供追溯，
但不入库、不进趋势）。不做「复核结果写回 Excel」的第二套链路（用户 11-01 默认：JSON 为准）。
"""

import datetime
import json
import os
import sys

import export
import rules

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)

VALID = ("approved", "rejected")


def build_result(date, items, skus, cfg, generated_at=None):
    """只给「需要人看」的行建条目：pending + 绿标抽中。"""
    decisions = {"item": {}, "sku": {}}

    for it in items:
        if it.get("review_status") == "pending" or it.get("sampled"):
            decisions["item"][it["product_id"]] = {
                "status": "",
                "note": "；".join(it.get("flags") or []),
                "reviewer": "",
                "sampled": bool(it.get("sampled")),
                "quality": it.get("quality"),
                "title": it.get("title", "")[:40],
                "price_list": it.get("price_list"),
                "price_detail": it.get("price_detail"),
            }
    for s in skus:
        if s.get("review_status") == "pending":
            decisions["sku"][s["sku_id"]] = {
                "status": "",
                "note": "；".join(s.get("flags") or []),
                "reviewer": "",
                "sampled": False,
                "quality": s.get("quality"),
                "product_id": s.get("product_id"),
                "prop_names": s.get("prop_names", "")[:60],
                "price": s.get("price"),
            }

    return {
        "date": date,
        "generated_at": generated_at or datetime.datetime.now().isoformat(timespec="seconds"),
        "policy": {
            "sample_ratio": cfg.get("sample_ratio"),
            "consume": "入库只消费 auto_pass / approved",
            "status_values": ["", "approved", "rejected"],
        },
        "decisions": decisions,
        "summary": {
            "item_pending": sum(1 for v in decisions["item"].values() if v["quality"] != "green"),
            "item_sampled": sum(1 for v in decisions["item"].values() if v["sampled"]),
            "sku_pending": len(decisions["sku"]),
        },
    }


def apply_result(items, skus, result):
    """把 decisions 应用到行。返回 {'approved','rejected','ignored','invalid'}。"""
    dec = (result or {}).get("decisions") or {}
    counters = {"approved": 0, "rejected": 0, "ignored": 0, "invalid": 0}
    now = datetime.datetime.now().isoformat(timespec="seconds")

    def _apply(rows, kind, key_name):
        mapping = dec.get(kind) or {}
        for r in rows:
            d = mapping.get(r.get(key_name))
            if not d:
                continue
            status = (d.get("status") or "").strip().lower()
            if not status:
                counters["ignored"] += 1
                continue
            if status not in VALID:
                counters["invalid"] += 1
                continue
            r["review_status"] = status
            r["reviewer"] = d.get("reviewer", "")
            r["review_note"] = d.get("note", "")
            r["reviewed_at"] = now
            counters[status] += 1

    _apply(items, "item", "product_id")
    _apply(skus, "sku", "sku_id")
    return counters


def rejected_rows(items, skus):
    """被复核驳回的行 -> anomalies（记录，不静默）。"""
    out = []
    for kind, rows, key in (("item", items, "product_id"), ("sku", skus, "sku_id")):
        for r in rows:
            if r.get("review_status") != "rejected":
                continue
            out.append({
                "crawl_date": r.get("crawl_date"), "product_id": r.get("product_id"),
                "sku_id": r.get("sku_id", ""), "level": "red", "rule": "review_rejected",
                "message": "人工复核驳回：%s" % (r.get("review_note") or "无备注"),
                "disposition": "dropped", "source_file": r.get("source_file", ""),
                "crawl_ts": r.get("crawl_ts") or r.get("detail_ts") or "",
                "payload": {"kind": kind, "title": r.get("title"),
                            "price": r.get("price") or r.get("price_detail"),
                            "flags": r.get("flags")},
            })
    return out


def load_result(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_result(path, result):
    return export.write_json(path, result)


# ------------------------------------------------------------
# CLI：建单 / 应用
# ------------------------------------------------------------
def main(args=None):
    args = args or {}
    clean_dir = args.get("clean_dir") or ""
    if not clean_dir:
        raise SystemExit("需要 --clean-dir")
    date = args.get("date") or rules.crawl_date_from_ts(
        os.path.basename(clean_dir.rstrip("\\/"))) or os.path.basename(clean_dir.rstrip("\\/"))
    result_path = os.path.join(clean_dir, "review_result.json")

    items, _ = export.read_jsonl(os.path.join(clean_dir, "item.jsonl"))
    skus, _ = export.read_jsonl(os.path.join(clean_dir, "sku.jsonl"))

    if args.get("apply"):
        result = load_result(result_path)
        counters = apply_result(items, skus, result)
        anomalies = rejected_rows(items, skus)
        export.write_jsonl(os.path.join(clean_dir, "item_reviewed.jsonl"), items)
        export.write_jsonl(os.path.join(clean_dir, "sku_reviewed.jsonl"), skus)
        if anomalies:
            old, _ = export.read_jsonl(os.path.join(clean_dir, "anomalies.jsonl"))
            export.write_jsonl(os.path.join(clean_dir, "anomalies.jsonl"), old + anomalies)
        print("复核应用：", counters)
        return counters

    result = build_result(date, items, skus, rules.DEFAULTS)
    write_result(result_path, result)
    print("复核单：", result_path, result["summary"])
    return result


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--clean-dir", required=True)
    ap.add_argument("--date", default="")
    ap.add_argument("--apply", action="store_true")
    main(vars(ap.parse_args()))
