"""清洗规则与归一化（L1 结构校验 + L2 业务规则）。

这一层只做「把一条记录变成可信的值」，不读写文件、不依赖 pandas。
所有阈值集中在 DEFAULTS，可用 clean.json / CLI 覆盖；代码里不写死。

三条纪律（与 §2.4c / §三 对齐）：
  1. 价格一律 float；转不出数字 = None，不补 0、不插值
  2. 销量只认「数字(+万)+人收货/付款」；其余置 None 并打 sales_non_numeric
     —— 裸 (\\d+) 会把「行业销量前20」里的 20 当成销量
  3. 打标不丢弃：每条异常都要能追到 rule / 原始值 / 来源文件
"""

import datetime
import json
import math
import os
import re

# ------------------------------------------------------------
# 默认参数
# ------------------------------------------------------------
DEFAULTS = {
    # L1 结构
    "price_min": 1.0,
    "price_max": 100000.0,

    # L3 统计离群（MAD）
    "mad_k": 3.0,
    "mad_scale": 1.4826,      # MAD → 标准差的换算系数（正态假设下）
    "min_history": 5,         # 同 SKU 历史不足 5 天 → 跳过 MAD，不硬判
    "history_days": 30,

    # L4 时序突变
    "spike_pct": 0.5,         # 较上次有效价变动 > 50% 且非大促期 → 打标

    # 复核
    "sample_ratio": 0.05,     # 绿标抽样比例
    "sample_seed": 20261101,
    # partial_sku 是否对 item 直接放行（true = 只有 scope=min 时算绿）
    "auto_pass_partial_min": False,

    # 图片
    "images": {
        "enabled": True,
        "timeout": 8,
        "workers": 8,
        "thumb_width": 200,
    },
}

# ------------------------------------------------------------
# 规则分级
# ------------------------------------------------------------
# 红：阻断，不进行情表；只留在 anomalies（disposition=dropped）
RED_RULES = {
    "missing_key": "主键缺失或非法",
    "price_nonpositive": "价格 ≤ 0",
    "price_out_of_range": "价格超出 1–100000",
    "key_conflict": "同一主键出现互斥内容",
}

# 黄：保留但进复核队列，复核前不进趋势
YELLOW_RULES = {
    "price_missing": "价格缺失",
    "price_detail_missing": "详情价缺失（列表价仅作触发器）",
    "sales_missing": "销量缺失",
    "sales_non_numeric": "销量非数值文案",
    "partial_sku": "SKU 价不完整",
    "image_broken": "主图不可用",
    "outlier": "偏离历史中位数（MAD）",
    "spike": "较上次有效价突变",
}

# 信息：记录事实，不影响分级
INFO_RULES = {
    "filtered": "被相关性过滤",
    "dup_replaced": "同日重复轮次，取最新",
    "price_conflict": "同日同 SKU 价格不一致，取最新完整轮",
    "sku_stale": "该 SKU 未出现在最新一轮",
    "detail_missing": "未深采（仅列表）",
    "image_skipped": "图片校验未启用",
    "sampled": "绿标抽检",
}

# 判定顺序：红 > 黄 > 绿
GRADE_ORDER = ("red", "yellow", "green")


# ------------------------------------------------------------
# 基础归一化
# ------------------------------------------------------------
def to_float(v):
    """任意输入 -> float | None。空、'--'、'***'、'暂无' 一律 None。"""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        if isinstance(v, float) and math.isnan(v):
            return None
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    s = s.replace("¥", "").replace("￥", "").replace(",", "").replace("，", "")
    try:
        return float(s)
    except ValueError:
        return None


def to_int(v):
    """任意输入 -> int | None。不把 None 当 0。"""
    f = to_float(v)
    if f is None:
        return None
    return int(f)


def norm_text(v):
    """去首尾空白与零宽字符；None -> ''。"""
    if v is None:
        return ""
    s = str(v)
    s = s.replace("​", "").replace("﻿", "")
    return s.strip()


def norm_id(v):
    """ID 一律 str：去 Excel 前导单引号、去 float 尾巴 .0、去空白。"""
    s = norm_text(v)
    if s.startswith("'"):
        s = s[1:]
    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]
    return s


def valid_product_id(pid):
    """商品 ID：纯数字且长度 ≥ 6（淘宝/天猫实测 11–13 位）。"""
    return bool(re.fullmatch(r"\d{6,}", pid or ""))


def valid_sku_id(sid):
    """SKU ID：纯数字，或单规格兜底的 <product_id>__default。"""
    if not sid:
        return False
    if sid.endswith("__default"):
        return valid_product_id(sid.split("__default")[0])
    return bool(re.fullmatch(r"\d+", sid))


def norm_url(u):
    """协议相对地址补 https；其余原样返回（不擅自改写商家链接）。"""
    s = norm_text(u)
    if s.startswith("//"):
        return "https:" + s
    return s


# ------------------------------------------------------------
# 销量归一（唯一入口）
# ------------------------------------------------------------
# 只认：<数字>[.<小数>][万]+?人(收货|付款)
# 例：'2000+人付款'→2000  '3万+人付款'→30000  '1.2万人收货'→12000
# 不认：'行业销量前20'（榜单词案）、'本月行业热销'、'--'
RE_SALES = re.compile(r"^(\d+(?:\.\d+)?)(万)?\+?人(收货|付款)$")


def norm_sales(raw):
    """销量原文 -> (int|None, flag|'')。

    返回的 flag 只会是 sales_missing（空）或 sales_non_numeric（有字但不认）。
    """
    s = re.sub(r"\s+", "", norm_text(raw))
    if not s:
        return None, "sales_missing"
    m = RE_SALES.match(s)
    if not m:
        return None, "sales_non_numeric"
    num = float(m.group(1))
    if m.group(2):
        num *= 10000.0
    return int(round(num)), ""


# ------------------------------------------------------------
# 时间 / 文件名
# ------------------------------------------------------------
def crawl_date_from_ts(ts):
    """'20261031_2355' / '2026-10-31' -> '2026-10-31'；认不出返回 ''。"""
    s = norm_text(ts)
    m = re.match(r"^(\d{4})(\d{2})(\d{2})(?:_|$)", s)
    if m:
        return "%s-%s-%s" % (m.group(1), m.group(2), m.group(3))
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
    if m:
        return s
    return ""


def crawl_ts_from_filename(path):
    """'20261031_2355.jsonl' -> '20261031_2355'；认不出返回 ''。"""
    base = os.path.basename(norm_text(path))
    m = re.match(r"^(\d{8}_\d{4,6})(?:\.|$)", base)
    return m.group(1) if m else ""


def today_str():
    return datetime.date.today().isoformat()


# ------------------------------------------------------------
# 详情价完整性
# ------------------------------------------------------------
def infer_price_complete(row):
    """老样本没有 price_complete 字段：用 coverage / flags 反推。

    宁可判 False 也不假装完整 —— 假完整会污染 SKU 趋势。
    """
    pc = row.get("price_complete")
    if isinstance(pc, bool):
        return pc
    cov = norm_text(row.get("price_coverage"))
    m = re.fullmatch(r"(\d+)/(\d+)", cov)
    if m:
        total = int(m.group(2))
        return total > 0 and int(m.group(1)) == total
    flags = row.get("flags") or []
    if isinstance(flags, str):
        flags = [f for f in flags.split(";") if f]
    return not any(f in ("partial_sku_price", "masked_price", "sku_count_mismatch")
                   for f in flags)


def split_flags(flags):
    if not flags:
        return []
    if isinstance(flags, str):
        return [f for f in flags.split(";") if f]
    return [str(f) for f in flags if f]


# 上游标记（采集链路）与质量标记分开：api 补价、单规格兜底这些是来源说明，
# 不是质量问题。上游标记进 source_flags，质量列只看 flags，避免报表误读。
KNOWN_QUALITY_FLAGS = set(RED_RULES) | set(YELLOW_RULES) | set(INFO_RULES)


def split_quality_flags(flags):
    """-> (quality_flags, source_flags)"""
    allf = split_flags(flags)
    quality = [f for f in allf if f in KNOWN_QUALITY_FLAGS]
    source = [f for f in allf if f not in KNOWN_QUALITY_FLAGS]
    return quality, source


# ------------------------------------------------------------
# 大促期（L4 突变豁免）
# ------------------------------------------------------------
def load_promo_periods(path):
    """读出 [(start_date, end_date, name), ...]；读不到返回 []。"""
    if not path or not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for year, periods in (cfg.get("promo_periods") or {}).items():
        for name, rng in (periods or {}).items():
            s, e = rng.get("start"), rng.get("end")
            if s and e:
                out.append((s, e, name))
    return out


def promo_name(date_str, periods):
    """命中大促返回促销名，否则 None。"""
    for s, e, name in periods or []:
        if s <= date_str <= e:
            return name
    return None


# ------------------------------------------------------------
# 分级
# ------------------------------------------------------------
def grade(flags):
    """flags -> 'red' | 'yellow' | 'green'。"""
    fs = set(flags or [])
    if fs & set(RED_RULES):
        return "red"
    if fs & set(YELLOW_RULES):
        return "yellow"
    return "green"


def rule_label(rule):
    return RED_RULES.get(rule) or YELLOW_RULES.get(rule) or INFO_RULES.get(rule) or rule


def load_config(path=None):
    """DEFAULTS + 可选 JSON 覆盖（浅合并，images 段深合并一层）。"""
    cfg = json.loads(json.dumps(DEFAULTS))   # 深拷贝
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            user = json.load(f)
        for k, v in (user or {}).items():
            if k == "images" and isinstance(v, dict):
                cfg["images"].update(v)
            else:
                cfg[k] = v
    return cfg


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")

    cases = ["2000+人付款", "3万+人付款", "1.2万人收货", "行业销量前20",
             "本月行业热销", "", None, "7000+人收货"]
    for c in cases:
        print("%-12r -> %s" % (c, norm_sales(c)))

    print("date 20261031_2355 ->", crawl_date_from_ts("20261031_2355"))
    print("price '--' ->", to_float("--"), "| '¥1,299.00' ->", to_float("¥1,299.00"))
    print("grade", grade(["sales_missing"]), grade(["missing_key"]), grade(["sales_missing", "missing_key"]))
