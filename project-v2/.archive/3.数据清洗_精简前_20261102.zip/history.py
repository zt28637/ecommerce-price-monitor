"""L3 MAD 离群 + L4 环比突变：只读历史 clean 文件，不依赖数据库。

数据源：runtime/v2/clean/<YYYY-MM-DD>/item.jsonl、sku.jsonl（历史上跑过的清洗产物）。
只用 review_status ∈ {auto_pass, approved} 的行；SKU 还要求 price_complete=true。
历史不足 min_history 天 → **跳过，不硬判**（写到 quality.json 的 history.skipped）。

为什么 MAD 不用 Z-score：价格长尾，Z-score 假设正态会把正常高价判成异常；
MAD 用中位数与中位差，对离群不敏感。

为什么环比不用「昨天 vs 今天」：断一天就整天不报。用「上一次有效价」天然跨空窗。
"""

import os
import sys

import export
import rules

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)

OK_STATUS = ("auto_pass", "approved")


# ------------------------------------------------------------
# 读历史
# ------------------------------------------------------------
def list_days(clean_root):
    """已有的清洗日期目录 -> [(ISO 日期, 目录名)]，升序。

    目录名按用户口径用 YYYYMMDD（如 clean/20261101），内部一律转 ISO 比较。
    """
    if not os.path.isdir(clean_root):
        return []
    out = []
    for name in os.listdir(clean_root):
        p = os.path.join(clean_root, name)
        iso = rules.crawl_date_from_ts(name)
        if os.path.isdir(p) and iso:
            out.append((iso, name))
    return sorted(out)


def _read_day(day_dir, name):
    """优先读复核后的产物：批准/驳回只在 *_reviewed.jsonl 里生效。"""
    reviewed = os.path.join(day_dir, name.replace(".jsonl", "_reviewed.jsonl"))
    if os.path.exists(reviewed):
        return export.read_jsonl(reviewed)
    return export.read_jsonl(os.path.join(day_dir, name))


def load_history(clean_root, date, days=None):
    """读 date 之前的清洗产物 -> {'items','skus','days','rows'}。"""
    days = days or rules.DEFAULTS["history_days"]
    all_days = [p for p in list_days(clean_root) if p[0] < date][-days:]

    items, skus, rows = {}, {}, 0
    for iso, dir_name in all_days:
        day_dir = os.path.join(clean_root, dir_name)
        i_rows, _ = _read_day(day_dir, "item.jsonl")
        for r in i_rows:
            if r.get("review_status") not in OK_STATUS:
                continue
            price = r.get("price_detail")
            if price is None:
                continue
            items.setdefault(r["product_id"], []).append((iso, float(price)))
            rows += 1
        s_rows, _ = _read_day(day_dir, "sku.jsonl")
        for r in s_rows:
            if r.get("review_status") not in OK_STATUS or not r.get("price_complete"):
                continue
            price = r.get("price")
            if price is None:
                continue
            skus.setdefault(r["sku_id"], []).append((iso, float(price)))
            rows += 1

    for series in list(items.values()) + list(skus.values()):
        series.sort(key=lambda x: x[0])
    return {"items": items, "skus": skus,
            "days": [iso for iso, _ in all_days], "rows": rows}


# ------------------------------------------------------------
# 统计小工具
# ------------------------------------------------------------
def _median(vals):
    v = sorted(vals)
    n = len(v)
    if not n:
        return None
    mid = n // 2
    return v[mid] if n % 2 else (v[mid - 1] + v[mid]) / 2.0


def mad_outlier(value, history, k, scale):
    """MAD 判定 -> (is_outlier, detail)。history 为空/太短由调用方先挡。"""
    med = _median(history)
    devs = [abs(x - med) for x in history]
    mad = _median(devs)
    if not mad:
        return False, {"median": med, "mad": mad, "reason": "mad_zero"}
    limit = k * scale * mad
    return abs(value - med) > limit, {"median": round(med, 2), "mad": round(mad, 4),
                                      "limit": round(limit, 2)}


def last_price(series):
    return series[-1][1] if series else None


# ------------------------------------------------------------
# 主入口
# ------------------------------------------------------------
def apply(items, skus, hist, cfg, promo_periods=None, date=None):
    """给行补 outlier / spike 标记。返回统计（写 quality.json）。"""
    stats = {
        "history_days": len(hist.get("days") or []),
        "history_rows": hist.get("rows", 0),
        "item_mad_checked": 0, "item_mad_skipped": 0,
        "sku_mad_checked": 0, "sku_mad_skipped": 0,
        "outliers": 0, "spikes": 0, "spike_suppressed_promo": 0,
        "mad_zero": 0,
    }
    k = float(cfg["mad_k"])
    scale = float(cfg["mad_scale"])
    min_hist = int(cfg["min_history"])
    spike_pct = float(cfg["spike_pct"])
    promo = rules.promo_name(date or "", promo_periods)

    # 商品级
    for it in items:
        series = [(d, p) for d, p in hist["items"].get(it["product_id"], [])
                  if d < it["crawl_date"]]
        cur = it.get("price_detail")
        if cur is None:
            continue
        if len(series) < min_hist:
            stats["item_mad_skipped"] += 1
        else:
            vals = [p for _, p in series]
            out, detail = mad_outlier(float(cur), vals, k, scale)
            if detail.get("reason") == "mad_zero":
                stats["mad_zero"] += 1
            stats["item_mad_checked"] += 1
            if out:
                it.setdefault("flags", []).append("outlier")
                it["outlier_detail"] = detail
                stats["outliers"] += 1
        prev = last_price(series)
        if prev and prev > 0 and abs(float(cur) - prev) / prev > spike_pct:
            if promo:
                stats["spike_suppressed_promo"] += 1
            else:
                it.setdefault("flags", []).append("spike")
                it["spike_detail"] = {"prev": prev, "cur": float(cur),
                                      "pct": round(abs(float(cur) - prev) / prev, 4)}
                stats["spikes"] += 1

    # SKU 级
    for s in skus:
        series = [(d, p) for d, p in hist["skus"].get(s["sku_id"], [])
                  if d < s["crawl_date"]]
        cur = s.get("price")
        if cur is None:
            continue
        if len(series) < min_hist:
            stats["sku_mad_skipped"] += 1
        else:
            vals = [p for _, p in series]
            out, detail = mad_outlier(float(cur), vals, k, scale)
            if detail.get("reason") == "mad_zero":
                stats["mad_zero"] += 1
            stats["sku_mad_checked"] += 1
            if out:
                s.setdefault("flags", []).append("outlier")
                s["outlier_detail"] = detail
                stats["outliers"] += 1
        prev = last_price(series)
        if prev and prev > 0 and abs(float(cur) - prev) / prev > spike_pct:
            if promo:
                stats["spike_suppressed_promo"] += 1
            else:
                s.setdefault("flags", []).append("spike")
                s["spike_detail"] = {"prev": prev, "cur": float(cur),
                                     "pct": round(abs(float(cur) - prev) / prev, 4)}
                stats["spikes"] += 1

    stats["promo"] = promo
    return stats


def main(args=None):
    args = args or {}
    root = args.get("clean_root") or ""
    return load_history(root, args.get("date") or rules.today_str(), args.get("days"))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    root = r"F:\Programs\RPA自动化\1-淘宝竞品价格监控自动化\project-v2\runtime\_sample\clean"
    h = load_history(root, "2026-11-01")
    print("days", h["days"], "rows", h["rows"],
          "items", len(h["items"]), "skus", len(h["skus"]))
