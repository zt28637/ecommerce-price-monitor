"""日报：HTML（缩略图 + 异常队列）与 Excel（数据 + 复核列）双份。

HTML 给人快速看：KPI、规则命中、红标丢弃、黄标/抽检队列（带缩略图）。
Excel 给表格人用：概览 / 异常队列 / 复核单（含空白复核列）/ item / sku / inventory。

默认两份都出（用户 11-01 未定项按推荐默认）。若只要 Excel：
run_clean --no-html；只要 HTML：--no-excel。
"""

import datetime
import html
import os
import sys

import export
from export import (INVENTORY_COLUMNS, ITEM_COLUMNS, SKU_COLUMNS)

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)

STATUS_CN = {"green": "绿", "yellow": "黄", "red": "红",
             "auto_pass": "自动通过", "pending": "待复核",
             "approved": "已通过", "rejected": "已驳回"}

SUMMARY_COLUMNS = [("metric", "指标", 26), ("value", "数值", 22), ("note", "说明", 60)]
QUEUE_COLUMNS = [
    ("kind", "类型", 8), ("key", "主键", 18), ("product_id", "商品ID", 16),
    ("title", "标题/规格", 46), ("price_list", "列表价", 10),
    ("price_detail", "详情价", 10), ("price", "SKU价", 10),
    ("flags", "标记", 30), ("quality", "质量", 8),
    ("review_status", "当前状态", 10), ("sampled", "抽检", 8),
    ("review_conclusion", "复核结论(approved/rejected)", 28),
    ("reviewer", "复核人", 12), ("review_note", "备注", 30),
]


def _e(v):
    return html.escape("" if v is None else str(v))


def _pct(v):
    try:
        return "%.1f%%" % (float(v) * 100)
    except (TypeError, ValueError):
        return "-"


def _money(v):
    return "-" if v is None else ("%.2f" % float(v))


def _thumb(it, images_rel):
    f = it.get("image_file") or ""
    if not f or not it.get("image_ok"):
        return '<span class="noimg">无图</span>'
    return ('<img class="thumb" src="%s/%s" alt="%s" loading="lazy">'
            % (_e(images_rel), _e(f), _e(it.get("product_id"))))


def _kpi(label, value, sub=""):
    return ('<div class="kpi"><div class="kpi-v">%s</div>'
            '<div class="kpi-l">%s</div><div class="kpi-s">%s</div></div>'
            % (_e(value), _e(label), _e(sub)))


# ------------------------------------------------------------
# HTML
# ------------------------------------------------------------
def build_html(date, items, skus, inventory, quality, anomalies,
               images_rel="images", top_n=200, generated_at=None):
    counts = quality.get("counts") or {}
    hits = quality.get("rule_hits") or {}
    cov = quality.get("coverage") or {}
    ratio = quality.get("list_detail_ratio") or {}
    history = quality.get("history") or {}
    generated_at = generated_at or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    reds = [a for a in anomalies if a.get("level") == "red"]
    queue = [it for it in items if it.get("in_queue")]
    sku_queue = [s for s in skus if s.get("review_status") == "pending"]

    kpis = "".join([
        _kpi("商品（天）", counts.get("item_total", 0)),
        _kpi("绿 / 黄", "%s / %s" % (counts.get("item_green", 0), counts.get("item_yellow", 0)),
             "通过率 %s" % _pct(quality.get("pass_rate"))),
        _kpi("红标丢弃", counts.get("item_red", 0), "禁入库，见 anomalies"),
        _kpi("有价 SKU", counts.get("sku_green", 0) + counts.get("sku_yellow", 0)),
        _kpi("无价库存", counts.get("inventory_rows", 0), "不记 0 价、不进趋势"),
        _kpi("详情价覆盖", _pct(cov.get("price_detail_ratio")),
             "完整 %s" % _pct(cov.get("price_complete_ratio"))),
        _kpi("销量覆盖", _pct(cov.get("sales_ratio"))),
        _kpi("主图可用", _pct(cov.get("image_ok_ratio"))),
        _kpi("待复核", counts.get("pending", 0),
             "绿标抽检 %s" % counts.get("sampled", 0)),
    ])

    hit_rows = "".join(
        "<tr><td>%s</td><td>%d</td></tr>" % (_e(k), v)
        for k, v in sorted(hits.items(), key=lambda x: -x[1])) or \
        '<tr><td colspan="2" class="muted">无</td></tr>'

    red_rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            _e(a.get("product_id")), _e(a.get("sku_id")), _e(a.get("rule")),
            _e(a.get("message")),
            _e((a.get("payload") or {}).get("price_detail")
               or (a.get("payload") or {}).get("price")))
        for a in reds[:top_n]) or \
        '<tr><td colspan="5" class="muted">无红标</td></tr>'

    q_rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            _thumb(it, images_rel), _e(it.get("product_id")),
            _e((it.get("title") or "")[:44]),
            "<br>".join([_e(_money(it.get("price_list"))), _e(_money(it.get("price_detail")))]),
            _e(" / ".join(it.get("flags") or [])),
            _e(STATUS_CN.get(it.get("review_status"), it.get("review_status"))))
        for it in queue[:top_n]) or \
        '<tr><td colspan="6" class="muted">无待复核商品</td></tr>'

    sku_rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            _e(s.get("sku_id")), _e(s.get("product_id")),
            _e((s.get("prop_names") or "")[:40]), _e(_money(s.get("price"))),
            _e(" / ".join(s.get("flags") or [])))
        for s in sku_queue[:top_n]) or \
        '<tr><td colspan="5" class="muted">无待复核 SKU</td></tr>'

    ratio_txt = ("n=%s  均值=%s  标准差=%s  区间=[%s, %s]" % (
        ratio.get("n"), ratio.get("mean"), ratio.get("std"),
        ratio.get("min"), ratio.get("max"))) if ratio.get("n") else "样本不足"

    hist_txt = ("历史 %s 天 / %s 行；MAD 检查 item %s、sku %s；离群 %s、突变 %s；"
                "大促期抑制 %s" % (
                    history.get("history_days", 0), history.get("history_rows", 0),
                    history.get("item_mad_checked", 0), history.get("sku_mad_checked", 0),
                    history.get("outliers", 0), history.get("spikes", 0),
                    history.get("spike_suppressed_promo", 0)))

    return """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>清洗日报 %(date)s</title>
<style>
:root{--fg:#1f2328;--muted:#6b7280;--line:#e5e7eb;--bg:#f7f8fa;--card:#fff;
--green:#e2efda;--yellow:#fff2cc;--red:#f8cbad;--accent:#1f4e78}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
font:14px/1.55 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
.wrap{max-width:1200px;margin:0 auto;padding:24px}
h1{font-size:22px;margin:0 0 4px}
h2{font-size:16px;margin:28px 0 10px;padding-left:9px;border-left:3px solid var(--accent)}
.sub{color:var(--muted);font-size:12px}
.kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:16px 0}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.kpi-v{font-size:22px;font-weight:600}
.kpi-l{color:var(--muted);font-size:12px}
.kpi-s{color:var(--muted);font-size:11px;margin-top:2px}
table{width:100%%;border-collapse:collapse;background:var(--card);
border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:7px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}
th{background:#f0f3f7;font-weight:600;font-size:12px;position:sticky;top:0}
tr:last-child td{border-bottom:0}
.muted{color:var(--muted)}
.thumb{width:54px;height:54px;object-fit:cover;border-radius:6px;border:1px solid var(--line)}
.noimg{display:inline-block;width:54px;text-align:center;color:var(--muted);font-size:11px}
.note{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;
color:var(--muted);font-size:12px}
code{background:#eef1f5;padding:1px 5px;border-radius:4px}
footer{margin:28px 0 8px;color:var(--muted);font-size:12px}
</style></head><body><div class="wrap">
<h1>数据清洗日报 · %(date)s</h1>
<div class="sub">生成时间 %(generated_at)s · 上游：list_raw / detail_raw · 下游：item / sku / inventory</div>
<div class="kpis">%(kpis)s</div>

<h2>规则命中</h2>
<table><thead><tr><th style="width:60%%">规则</th><th>次数</th></tr></thead>
<tbody>%(hit_rows)s</tbody></table>

<h2>红标（已丢弃，禁入库）</h2>
<table><thead><tr><th>商品ID</th><th>SKU</th><th>规则</th><th>说明</th><th>价格</th></tr></thead>
<tbody>%(red_rows)s</tbody></table>

<h2>待复核 / 抽检（黄标，复核前不进趋势）</h2>
<table><thead><tr><th>主图</th><th>商品ID</th><th>标题</th><th>列表价 / 详情价</th>
<th>标记</th><th>状态</th></tr></thead>
<tbody>%(q_rows)s</tbody></table>

<h2>待复核 SKU</h2>
<table><thead><tr><th>SKU ID</th><th>商品ID</th><th>规格</th><th>价格</th><th>标记</th></tr></thead>
<tbody>%(sku_rows)s</tbody></table>

<h2>诊断</h2>
<div class="note">
<p><b>列表价 vs 详情价</b>：%(ratio_txt)s（比值 = 详情价 / 列表价；波动大说明列表价只能当触发器）</p>
<p><b>历史 / 离群</b>：%(hist_txt)s</p>
<p><b>口径</b>：红=禁入库；黄=保留待复核、复核前不进趋势；绿=auto_pass。
无价 SKU 进 <code>inventory</code>，不记 0 价。详情价才是趋势价。</p>
</div>

<footer>产物：item.xlsx/jsonl · sku.xlsx/jsonl · inventory.jsonl · quality.json ·
anomalies.jsonl · review_result.json · images/</footer>
</div></body></html>
""" % {
        "date": _e(date), "generated_at": _e(generated_at), "kpis": kpis,
        "hit_rows": hit_rows, "red_rows": red_rows, "q_rows": q_rows,
        "sku_rows": sku_rows, "ratio_txt": _e(ratio_txt), "hist_txt": _e(hist_txt),
    }


# ------------------------------------------------------------
# Excel
# ------------------------------------------------------------
def _summary_rows(quality):
    c = quality.get("counts") or {}
    cov = quality.get("coverage") or {}
    ratio = quality.get("list_detail_ratio") or {}
    hist = quality.get("history") or {}
    rows = [
        {"metric": "商品·天", "value": c.get("item_total"), "note": "item 表行数"},
        {"metric": "绿 / 黄 / 红", "value": "%s / %s / %s" % (
            c.get("item_green"), c.get("item_yellow"), c.get("item_red")),
         "note": "红标不进表；黄标待复核"},
        {"metric": "通过率", "value": _pct(quality.get("pass_rate")), "note": "绿 / 商品总数"},
        {"metric": "有价 SKU", "value": c.get("sku_green", 0) + c.get("sku_yellow", 0),
         "note": "sku 表"},
        {"metric": "无价库存", "value": c.get("inventory_rows"), "note": "inventory 表"},
        {"metric": "待复核", "value": c.get("pending"), "note": "item + sku pending"},
        {"metric": "绿标抽检", "value": c.get("sampled"), "note": "5% 抽样"},
        {"metric": "详情价覆盖", "value": _pct(cov.get("price_detail_ratio")), "note": ""},
        {"metric": "价格完整率", "value": _pct(cov.get("price_complete_ratio")), "note": "price_complete"},
        {"metric": "销量覆盖", "value": _pct(cov.get("sales_ratio")), "note": ""},
        {"metric": "主图可用", "value": _pct(cov.get("image_ok_ratio")), "note": ""},
        {"metric": "列表/详情价比值", "value": ratio.get("mean"),
         "note": "n=%s std=%s" % (ratio.get("n"), ratio.get("std"))},
        {"metric": "历史 / 离群 / 突变", "value": "%s 天 / %s / %s" % (
            hist.get("history_days", 0), hist.get("outliers", 0), hist.get("spikes", 0)),
         "note": "MAD + 环比"},
    ]
    for k, v in sorted((quality.get("rule_hits") or {}).items(), key=lambda x: -x[1]):
        rows.append({"metric": "规则:" + k, "value": v, "note": ""})
    return rows


def build_queue_rows(items, skus):
    rows = []
    for it in items:
        if not it.get("in_queue"):
            continue
        rows.append({
            "kind": "item", "key": it.get("product_id"),
            "product_id": it.get("product_id"), "title": it.get("title"),
            "price_list": it.get("price_list"), "price_detail": it.get("price_detail"),
            "price": None, "flags": " / ".join(it.get("flags") or []),
            "quality": it.get("quality"), "review_status": it.get("review_status"),
            "sampled": "TRUE" if it.get("sampled") else "FALSE",
            "review_conclusion": "", "reviewer": "", "review_note": "",
        })
    for s in skus:
        if s.get("review_status") != "pending":
            continue
        rows.append({
            "kind": "sku", "key": s.get("sku_id"),
            "product_id": s.get("product_id"), "title": s.get("prop_names"),
            "price_list": None, "price_detail": None, "price": s.get("price"),
            "flags": " / ".join(s.get("flags") or []),
            "quality": s.get("quality"), "review_status": s.get("review_status"),
            "sampled": "FALSE", "review_conclusion": "", "reviewer": "", "review_note": "",
        })
    return rows


def save(date, items, skus, inventory, quality, anomalies, out_dir,
         html_enabled=True, excel_enabled=True, images_rel="images", top_n=200):
    """写日报_<date>.html / .xlsx。返回路径列表。"""
    paths = []
    export.ensure_dir(out_dir)
    if html_enabled:
        text = build_html(date, items, skus, inventory, quality, anomalies,
                          images_rel=images_rel, top_n=top_n)
        p = os.path.join(out_dir, "日报_%s.html" % date)
        export.atomic_write_text(p, text)
        paths.append(p)
    if excel_enabled:
        p = os.path.join(out_dir, "日报_%s.xlsx" % date)
        sheets = [
            ("概览", _summary_rows(quality), SUMMARY_COLUMNS),
            ("异常队列", build_queue_rows(items, skus), QUEUE_COLUMNS),
            ("item", items, ITEM_COLUMNS),
            ("sku", skus, SKU_COLUMNS),
            ("inventory", inventory, INVENTORY_COLUMNS),
            ("说明", [
                {"metric": "复核怎么填", "value": "approved / rejected",
                 "note": "JSON 为准：改 review_result.json 的 decisions，再跑 review.py --apply"},
                {"metric": "黄标处理", "value": "approved 后进趋势",
                 "note": "rejected 保留在 *_reviewed.jsonl 供追溯，不入库"},
                {"metric": "红标", "value": "已丢弃",
                 "note": "见 anomalies.jsonl，不静默丢"},
            ], SUMMARY_COLUMNS),
        ]
        export.write_xlsx(p, sheets)
        paths.append(p)
    return paths


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print("report.py: 由 run_clean 调用；单独运行请见 run_clean.py --help")
