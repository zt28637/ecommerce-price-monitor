"""主图校验：HEAD/GET -> 下载 -> Pillow 读尺寸 -> 缩略图。

纪律：
  · 只校验列表主图；SKU 图第一版不做（用户 11-01 定）
  · 失败打 image_broken（黄），不丢商品
  · 没有主图链接 ≠ 图片坏：detail_only 商品本来就没有列表主图
  · 同一 URL 当天只下一次，结果写 images/index.json，重跑不重复打 CDN
  · 未启用（--no-images）时 image_ok 保持 None，不判坏

缩略图给日报 HTML 用；复核单跟着 images/ 目录一起转发即可看。
"""

import hashlib
import io
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import export

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)

try:
    import requests
except ImportError:          # 离线环境不装 requests 也要能 import 本模块
    requests = None

try:
    from PIL import Image
except ImportError:
    Image = None

MAX_BYTES = 8 * 1024 * 1024
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")


def _ext_from(content_type, url, meta):
    ct = (content_type or "").lower()
    for key, ext in (("webp", ".webp"), ("png", ".png"), ("jpeg", ".jpg"),
                     ("jpg", ".jpg"), ("gif", ".gif"), ("avif", ".avif")):
        if key in ct:
            return ext
    m = meta.get("format")
    if m:
        return ".jpg" if m.lower() in ("jpeg", "jpg") else "." + m.lower()
    path = (url or "").split("?")[0].lower()
    for ext in (".webp", ".jpg", ".jpeg", ".png", ".gif"):
        if path.endswith(ext):
            return ".jpg" if ext == ".jpeg" else ext
    return ".jpg"


def _fetch(url, timeout):
    """GET 拿字节（HEAD 在部分 CDN 会 403/405，直接用 GET 更省一次往返）。"""
    if requests is None:
        raise RuntimeError("requests 未安装")
    r = requests.get(url, timeout=timeout, headers={"User-Agent": UA}, stream=True)
    try:
        if r.status_code >= 400:
            raise RuntimeError("HTTP %s" % r.status_code)
        buf = b""
        for chunk in r.iter_content(64 * 1024):
            buf += chunk
            if len(buf) > MAX_BYTES:
                raise RuntimeError("图片超过 8MB")
        return buf, r.headers.get("Content-Type", "")
    finally:
        r.close()


def _probe_meta(buf):
    if Image is None:
        return None
    try:
        with Image.open(io.BytesIO(buf)) as im:
            return {"w": im.width, "h": im.height, "format": im.format}
    except Exception:
        return None


def _make_thumb(buf, out_path, width):
    """缩略图失败不影响校验结论。"""
    if Image is None:
        return False
    try:
        with Image.open(io.BytesIO(buf)) as im:
            im = im.convert("RGB")
            ratio = width / float(im.width)
            im = im.resize((width, max(1, int(im.height * ratio))))
            im.save(out_path, "JPEG", quality=82)
        return True
    except Exception:
        return False


def check_one(url, out_dir, width, timeout):
    """下载 + 读尺寸 + 缩略图。返回 dict（永不抛异常）。"""
    result = {"url": url, "ok": False, "width": None, "height": None,
              "file": "", "thumb": "", "error": ""}
    if not url:
        result["error"] = "no_url"
        return result
    try:
        buf, ctype = _fetch(url, timeout)
        meta = _probe_meta(buf)
        if not meta:
            result["error"] = "not_an_image"
            return result
        ext = _ext_from(ctype, url, meta)
        digest = hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
        name = "img_%s%s" % (digest, ext)
        path = os.path.join(out_dir, name)
        with open(path, "wb") as f:
            f.write(buf)
        thumb = os.path.join(out_dir, "thumb_" + os.path.splitext(name)[0] + ".jpg")
        if not _make_thumb(buf, thumb, width):
            thumb = ""
        result.update(ok=True, width=meta["w"], height=meta["h"],
                      file=os.path.basename(path),
                      thumb=os.path.basename(thumb) if thumb else "")
    except Exception as e:
        result["error"] = "%s: %s" % (type(e).__name__, str(e)[:120])
    return result


def _load_index(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def run(items, out_dir, cfg):
    """给 item 行补 image_ok / image_width / image_height / image_file。

    返回 stats：{'enabled','checked','ok','broken','cached','skipped_no_url'}
    """
    icons = cfg.get("images") or {}
    enabled = bool(icons.get("enabled", True))
    stats = {"enabled": enabled, "checked": 0, "ok": 0, "broken": 0,
             "cached": 0, "skipped_no_url": 0}
    if not enabled:
        return stats

    out_dir = export.ensure_dir(out_dir)
    index_path = os.path.join(out_dir, "index.json")
    index = _load_index(index_path)

    todo = []
    for it in items:
        url = it.get("main_image_url") or ""
        if not url:
            stats["skipped_no_url"] += 1
            continue
        # 只复用成功结果；昨天/上一轮失败的允许重试，避免一次网络抖动锁死一天
        if url in index and index[url].get("ok"):
            stats["cached"] += 1
            _apply(it, index[url])
        else:
            todo.append(it)

    if todo:
        workers = int(icons.get("workers") or 8)
        timeout = float(icons.get("timeout") or 8)
        width = int(icons.get("thumb_width") or 200)
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            futures = {pool.submit(check_one, it["main_image_url"], out_dir, width, timeout): it
                       for it in todo}
            for fut in as_completed(futures):
                it = futures[fut]
                res = fut.result()
                index[it["main_image_url"]] = res
                _apply(it, res)
                stats["checked"] += 1

    for it in items:
        if it.get("image_ok"):
            stats["ok"] += 1
        elif it.get("main_image_url") and it.get("image_ok") is False:
            stats["broken"] += 1

    export.write_json(index_path, index)
    return stats


def _apply(it, res):
    it["image_ok"] = bool(res.get("ok"))
    it["image_width"] = res.get("width")
    it["image_height"] = res.get("height")
    it["image_file"] = res.get("thumb") or res.get("file") or ""
    if not res.get("ok"):
        it["image_error"] = res.get("error", "")


def main(args=None):
    args = args or {}
    return run(args.get("items") or [], args.get("out_dir") or "", args.get("cfg") or {})


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    root = r"F:\Programs\RPA自动化\1-淘宝竞品价格监控自动化\project-v2\runtime\_sample\imgtest"
    rows = [{"main_image_url": "https://g-search3.alicdn.com/img/bao/uploaded/i4/i3/760711426/"
                              "O1CN01LHBumxzOrXD2vH2e_!!4611686018427382018-0-item_pic.jpg"}]
    st = run(rows, root, {"images": {"enabled": True, "timeout": 10, "workers": 2,
                                     "thumb_width": 200}})
    print(st)
    print(rows[0].get("image_ok"), rows[0].get("image_width"), rows[0].get("image_height"),
          rows[0].get("image_file"))
