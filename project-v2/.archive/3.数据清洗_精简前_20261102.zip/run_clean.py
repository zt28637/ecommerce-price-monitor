"""清洗总入口：list_raw + detail_raw -> clean/<date>/ 全套产物 + 日报。

用法（系统 Python，不依赖影刀 venv）：
  python run_clean.py --date 2026-11-01 \
      --list-raw  runtime/v2/_sample/list_raw \
      --detail-raw runtime/v2/_sample/detail_raw

  # 没有 list_raw 时，可从已保存的列表页 HTML 现生成（回归用）
  python run_clean.py --date 2026-11-01 --list-html runtime/v2/samples/小天才电话手表1.html \
      --list-ts 20261101_0900 --detail-raw runtime/v2/_sample/detail_raw

流程（顺序不能换）：
  读 list -> 清洗去重 -> 读 detail -> 清洗去重 -> 合并 item
  -> 主图校验 -> L3/L4 历史打标 -> 红黄绿分级 -> 复核单 -> 落盘 -> 日报

不做：入库、登录、画布、详情采集。
"""

import argparse
import datetime
import importlib.util
import os
import sys

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)

import clean_detail
import clean_list
import clean_merge
import export
import history
import image_check
import quality
import report
import review
import rules

DEFAULT_ROOT = r"F:\Programs\RPA自动化\1-淘宝竞品价格监控自动化\project-v2\runtime"
DEFAULT_CONFIG = r"F:\Programs\RPA自动化\1-淘宝竞品价格监控自动化\project-v2\config\targets.json"
PROMO_CONFIG = r"F:\Programs\RPA自动化\1-淘宝竞品价格监控自动化\project-v2\config\promo_dates.json"
LIST_MODULE_DIR = os.path.join(os.path.dirname(_MODULE_DIR), "1.列表页采集")


def _log(msg):
    print(msg)
    sys.stdout.flush()


# ------------------------------------------------------------
# 从 HTML 现生成 list_raw（回归 / 补跑）
# ------------------------------------------------------------
def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def generate_list_raw(html_path, ts, root, config_path=None):
    """parse_list + filter_item -> list_raw/<目标>/<ts>.jsonl，返回文件路径。"""
    parse_list = _load_module("parse_list", os.path.join(LIST_MODULE_DIR, "parse_list.py"))
    filter_item = _load_module("filter_item", os.path.join(LIST_MODULE_DIR, "filter_item.py"))

    ruleset = filter_item.load_rules(config_path or DEFAULT_CONFIG)
    with open(html_path, "r", encoding="utf-8", errors="replace") as f:
        rows = parse_list.parse_list_html(f.read())
    marked = filter_item.filter_rows(rows, ruleset)["all"]

    out_dir = export.ensure_dir(os.path.join(root, "list_raw", ruleset["name"]))
    out_path = os.path.join(out_dir, ts + ".jsonl")
    export.write_jsonl(out_path, marked)
    _log("[清洗] 由 HTML 生成 list_raw：%s（%d 行）" % (out_path, len(marked)))
    return out_path


# ------------------------------------------------------------
# 主流程
# ------------------------------------------------------------
def run(args):
    cfg = rules.load_config(args.get("config"))
    if args.get("no_images"):
        cfg["images"]["enabled"] = False
    if args.get("sample_ratio") is not None:
        cfg["sample_ratio"] = float(args["sample_ratio"])
    if args.get("min_history") is not None:
        cfg["min_history"] = int(args["min_history"])
    if args.get("history_days") is not None:
        cfg["history_days"] = int(args["history_days"])
    if args.get("auto_pass_partial_min"):
        cfg["auto_pass_partial_min"] = True

    root = args.get("root") or DEFAULT_ROOT
    date = args.get("date") or rules.today_str()
    # 目录按用户口径用 YYYYMMDD；行内 crawl_date 仍是 YYYY-MM-DD
    out_dir = args.get("out") or os.path.join(root, "clean", date.replace("-", ""))
    export.ensure_dir(out_dir)
    images_dir = export.ensure_dir(os.path.join(out_dir, "images"))

    # 0) 可选的 list_raw 现生成（多个 HTML -> 多轮，用来验证同日去重）
    list_paths = list(args.get("list_raw") or [])
    htmls = args.get("list_html") or []
    if isinstance(htmls, str):
        htmls = [htmls] if htmls else []
    tss = args.get("list_ts") or []
    if isinstance(tss, str):
        tss = [tss] if tss else []
    for i, html_path in enumerate(htmls):
        ts = tss[i] if i < len(tss) and tss[i] else \
            datetime.datetime.now().strftime("%Y%m%d_%H%M")
        list_paths.append(generate_list_raw(html_path, ts, root, args.get("config")))

    # 1) 列表
    lst = clean_list.clean_files([p for p in list_paths if p], date=date)
    _log("[清洗] 列表：原始 %(raw_rows)d -> 去重 %(deduped)d -> 通过 %(passed)d / 过滤 %(filtered)d"
         % lst["stats"])
    _log("        过滤原因：%s" % (lst["stats"]["filter_reasons"] or "无"))

    # 2) 详情
    det = clean_detail.clean_files([p for p in (args.get("detail_raw") or []) if p], date=date)
    _log("[清洗] 详情：原始 %(raw_rows)d -> 商品 %(products)d | 有价 SKU %(skus_priced)d"
         " | 无价库存 %(inventory_rows)d" % det["stats"])

    # 3) 合并
    items, merge_anomalies = clean_merge.merge(lst["items"], det["item_details"], det["skus"])
    _log("[清洗] 合并：item %d 行（both %d / list_only %d / detail_only %d）" % (
        len(items),
        sum(1 for r in items if r["merge_status"] == "both"),
        sum(1 for r in items if r["merge_status"] == "list_only"),
        sum(1 for r in items if r["merge_status"] == "detail_only")))

    # 4) 主图
    img_stats = image_check.run(items, images_dir, cfg)
    for it in items:
        if it.get("main_image_url") and it.get("image_ok") is False:
            it["flags"].append("image_broken")
    _log("[清洗] 主图：启用=%s 校验=%s 可用=%s 坏=%s 跳过(无链接)=%s" % (
        img_stats["enabled"], img_stats["checked"], img_stats["ok"],
        img_stats["broken"], img_stats["skipped_no_url"]))

    # 5) 历史 L3/L4
    hist = history.load_history(root and os.path.join(root, "clean"), date, cfg["history_days"])
    hist_stats = history.apply(items, det["skus"], hist, cfg,
                               rules.load_promo_periods(PROMO_CONFIG), date=date)
    _log("[清洗] 历史：%s 天 / %s 行 -> 离群 %s、突变 %s、大促抑制 %s" % (
        hist_stats["history_days"], hist_stats["history_rows"],
        hist_stats["outliers"], hist_stats["spikes"], hist_stats["spike_suppressed_promo"]))

    # 6) 分级（红行在此剔除）
    anomalies = (lst["anomalies"] + det["anomalies"] + merge_anomalies)
    qres = quality.assign(items, det["skus"], det["inventory"], cfg, anomalies)
    kept_items = qres["items"]
    kept_skus = qres["skus"]
    kept_inv = qres["inventory"]
    qstats = qres["stats"]
    _log("[清洗] 分级：item 绿 %(item_green)d / 黄 %(item_yellow)d / 红 %(item_red)d | "
         "sku 绿 %(sku_green)d / 黄 %(sku_yellow)d / 红 %(sku_dropped)d | 待复核 %(pending)d"
         % qstats)

    # 7) 复核单
    result = review.build_result(date, kept_items, kept_skus, cfg)
    review.write_result(os.path.join(out_dir, "review_result.json"), result)

    # 8) 质量报告 + 落盘
    quality_obj = quality.build_report(date, qstats, kept_items, cfg, history=hist_stats, extra={
        "list": {k: v for k, v in lst["stats"].items() if k != "files"},
        "detail": {k: v for k, v in det["stats"].items() if k != "files"},
        "images": img_stats,
        "files": {"list": lst["stats"]["files"], "detail": det["stats"]["files"]},
    })

    export.write_jsonl(os.path.join(out_dir, "item.jsonl"), kept_items)
    export.write_jsonl(os.path.join(out_dir, "sku.jsonl"), kept_skus)
    export.write_jsonl(os.path.join(out_dir, "inventory.jsonl"), kept_inv)
    export.write_jsonl(os.path.join(out_dir, "anomalies.jsonl"), qres["anomalies"])
    export.write_json(os.path.join(out_dir, "quality.json"), quality_obj)
    export.write_xlsx(os.path.join(out_dir, "item.xlsx"),
                      [("item", kept_items, export.ITEM_COLUMNS)])
    export.write_xlsx(os.path.join(out_dir, "sku.xlsx"),
                      [("sku", kept_skus, export.SKU_COLUMNS)])

    # 9) 日报
    paths = report.save(date, kept_items, kept_skus, kept_inv, quality_obj, qres["anomalies"],
                        out_dir, html_enabled=not args.get("no_html"),
                        excel_enabled=not args.get("no_excel"))

    meta = {
        "date": date,
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "out_dir": out_dir,
        "args": {k: v for k, v in args.items() if k != "cfg"},
        "counts": qstats,
        "history": hist_stats,
        "images": img_stats,
        "outputs": paths + [
            os.path.join(out_dir, n) for n in
            ("item.jsonl", "item.xlsx", "sku.jsonl", "sku.xlsx", "inventory.jsonl",
             "quality.json", "anomalies.jsonl", "review_result.json")],
    }
    export.write_json(os.path.join(out_dir, "run_meta.json"), meta)

    _log("[清洗] 产物目录：%s" % out_dir)
    for p in meta["outputs"]:
        _log("        - %s" % os.path.basename(p))
    return {"out_dir": out_dir, "counts": qstats, "quality": quality_obj, "meta": meta}


# ------------------------------------------------------------
# 影刀入口（预留）
# ------------------------------------------------------------
def main(args=None):
    return run(args or {})


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="v2 数据清洗")
    ap.add_argument("--date", default="", help="采集日期 YYYY-MM-DD；默认今天")
    ap.add_argument("--list-raw", action="append", default=[], help="list_raw 文件或目录，可重复")
    ap.add_argument("--detail-raw", action="append", default=[], help="detail_raw 文件或目录，可重复")
    ap.add_argument("--list-html", action="append", default=[],
                    help="无 list_raw 时从列表页 HTML 现生成，可重复")
    ap.add_argument("--list-ts", action="append", default=[],
                    help="现生成 JSONL 的轮次号 YYYYMMDD_HHMM，与 --list-html 顺序对应")
    ap.add_argument("--root", default=DEFAULT_ROOT, help="runtime/v2 根目录")
    ap.add_argument("--out", default="", help="输出目录；默认 <root>/clean/<date>")
    ap.add_argument("--config", default="", help="清洗参数 JSON（可选）")
    ap.add_argument("--no-images", action="store_true", help="跳过主图校验")
    ap.add_argument("--no-html", action="store_true", help="不出 HTML 日报")
    ap.add_argument("--no-excel", action="store_true", help="不出 Excel 日报")
    ap.add_argument("--sample-ratio", type=float, default=None, help="绿标抽检比例")
    ap.add_argument("--min-history", type=int, default=None, help="MAD 最少历史天数")
    ap.add_argument("--history-days", type=int, default=None, help="回看历史天数")
    ap.add_argument("--auto-pass-partial-min", action="store_true",
                    help="scope=min 的 partial_sku 直接放行（默认关闭）")
    run(vars(ap.parse_args()))
