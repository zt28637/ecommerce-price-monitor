"""质量分级与复核状态（红 / 黄 / 绿）。

红：主键缺失、价格 ≤ 0 或越界、主键互斥冲突 —— **不进 item/sku 表**，只留 anomalies
黄：缺价 / 缺销量 / partial_sku / 离群 / 突变 / 图片坏 —— 保留、进复核队列、复核前不进趋势
绿：auto_pass；按 sample_ratio 抽检（抽中的仍 auto_pass，只是在复核单里多看一眼）

分级只看标记，不在这里做统计计算（MAD / 环比在 history.py）。
"""

import hashlib
import math
import os
import sys

from rules import YELLOW_RULES, grade, rule_label, valid_product_id, valid_sku_id

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
if _MODULE_DIR not in sys.path:
    sys.path.insert(0, _MODULE_DIR)


# ------------------------------------------------------------
# 价格合法性
# ------------------------------------------------------------
def price_problem(value, cfg, field):
    """-> (rule, message) | None"""
    if value is None:
        return None
    if value <= 0:
        return "price_nonpositive", "%s = %s" % (field, value)
    if not (cfg["price_min"] <= value <= cfg["price_max"]):
        return "price_out_of_range", "%s = %s" % (field, value)
    return None


def _item_red_flags(row, cfg):
    flags, msgs = [], []
    if not valid_product_id(row.get("product_id")):
        flags.append("missing_key")
        msgs.append("商品 ID 非法：%r" % row.get("product_id"))
    for field in ("price_list", "price_detail", "min_sku_price", "max_sku_price"):
        p = price_problem(row.get(field), cfg, field)
        if p:
            flags.append(p[0])
            msgs.append(p[1])
    if "key_conflict" in (row.get("flags") or []):
        flags.append("key_conflict")
        msgs.append("主键互斥冲突")
    return flags, msgs


def _sku_red_flags(row, cfg):
    flags, msgs = [], []
    if not valid_sku_id(row.get("sku_id")) or not valid_product_id(row.get("product_id")):
        flags.append("missing_key")
        msgs.append("SKU/商品 ID 非法")
    p = price_problem(row.get("price"), cfg, "price")
    if p:
        flags.append(p[0])
        msgs.append(p[1])
    if "key_conflict" in (row.get("flags") or []):
        flags.append("key_conflict")
        msgs.append("SKU 身份冲突")
    return flags, msgs


# ------------------------------------------------------------
# 抽样：确定性哈希，重跑同一份数据抽到同一批
# ------------------------------------------------------------
def is_sampled(crawl_date, pid, ratio, seed):
    if ratio <= 0:
        return False
    h = hashlib.sha1(("%s|%s|%s" % (crawl_date, pid, seed)).encode("utf-8")).hexdigest()
    return (int(h[:8], 16) / float(0xFFFFFFFF)) < ratio


# ------------------------------------------------------------
# 主入口
# ------------------------------------------------------------
def assign(items, skus, inventory, cfg, extra_anomalies=None):
    """分级 + 剔除红行 + 定复核状态。

    返回 {'items','skus','inventory','dropped','anomalies','stats','sampled'}
    dropped 是被剔除的红行（保留完整行，便于排查 / 人工放行）。
    """
    anomalies = list(extra_anomalies or [])
    rule_hits = {}
    dropped = []

    kept_items = []
    for it in items:
        red, msgs = _item_red_flags(it, cfg)
        if red:
            for f, msg in zip(red, msgs):
                rule_hits[f] = rule_hits.get(f, 0) + 1
                anomalies.append(_anomaly(it, f, "red", "dropped", msg))
            dropped.append(("item", it))
            continue

        flags = list(it.get("flags") or [])
        if "key_conflict" in flags:
            flags.remove("key_conflict")

        # 可选：scope=min 的 partial 视为可接受（默认关闭，保持用户口径）
        if cfg.get("auto_pass_partial_min"):
            only_partial = set(flags) <= {"partial_sku"}
            if only_partial and it.get("item_price_scope") == "min":
                flags = [f for f in flags if f != "partial_sku"]

        it["flags"] = sorted(set(flags))
        it["quality"] = grade(it["flags"])
        it["review_status"] = "auto_pass" if it["quality"] == "green" else "pending"
        it["sampled"] = bool(it["quality"] == "green" and is_sampled(
            it["crawl_date"], it["product_id"], cfg["sample_ratio"], cfg["sample_seed"]))
        it["in_queue"] = bool(it["quality"] != "green" or it["sampled"])

        for f in it["flags"]:
            rule_hits[f] = rule_hits.get(f, 0) + 1
        if it["quality"] != "green":
            for f in it["flags"]:
                if f in YELLOW_RULES:
                    anomalies.append(_anomaly(it, f, "yellow", "kept",
                                              "打标进复核队列：%s" % rule_label(f)))
        if it["sampled"]:
            anomalies.append(_anomaly(it, "sampled", "info", "kept",
                                      "绿标 5%% 抽检：%s" % it["product_id"]))
        kept_items.append(it)

    kept_skus = []
    for s in skus:
        red, msgs = _sku_red_flags(s, cfg)
        if red:
            for f, msg in zip(red, msgs):
                rule_hits[f] = rule_hits.get(f, 0) + 1
                anomalies.append(_anomaly(s, f, "red", "dropped", msg))
            dropped.append(("sku", s))
            continue
        s["flags"] = sorted(set(s.get("flags") or []))
        s["quality"] = grade(s["flags"])
        s["review_status"] = "auto_pass" if s["quality"] == "green" else "pending"
        s["in_queue"] = bool(s["quality"] != "green")
        for f in s["flags"]:
            if f in YELLOW_RULES:
                rule_hits[f] = rule_hits.get(f, 0) + 1
                anomalies.append(_anomaly(s, f, "yellow", "kept",
                                          "打标进复核队列：%s" % rule_label(f)))
        kept_skus.append(s)

    # 无价库存：no price by construction；不进趋势、不占复核队列。
    # 逐行记 anomalies 会把队列冲垮，按商品聚合一条 info。
    kept_inv = []
    inv_by_pid = {}
    for v in inventory:
        v["flags"] = sorted(set((v.get("flags") or []) + ["price_missing"]))
        v["quality"] = "yellow"
        v["review_status"] = "auto_pass"
        v["in_queue"] = False
        kept_inv.append(v)
        inv_by_pid.setdefault(v["product_id"], []).append(v)
    for pid, rows in sorted(inv_by_pid.items()):
        anomalies.append({
            "crawl_date": rows[0]["crawl_date"], "product_id": pid, "sku_id": "",
            "level": "info", "rule": "price_missing",
            "message": "无价库存 %d 个 SKU（%s），保留库存事实、不进价格趋势"
                       % (len(rows), rows[0].get("reason") or "price_null"),
            "disposition": "kept", "source_file": rows[0].get("source_file", ""),
            "crawl_ts": rows[0].get("crawl_ts", ""),
            "payload": {"skus": [r["sku_id"] for r in rows],
                        "quantities": [r.get("quantity") for r in rows]},
        })

    green = sum(1 for r in kept_items if r["quality"] == "green")
    yellow = sum(1 for r in kept_items if r["quality"] == "yellow")
    stats = {
        "item_total": len(items),
        "item_green": green,
        "item_yellow": yellow,
        "item_red": len([1 for kind, _ in dropped if kind == "item"]),
        "item_dropped": len([1 for kind, _ in dropped if kind == "item"]),
        "sku_total": len(skus),
        "sku_green": sum(1 for r in kept_skus if r["quality"] == "green"),
        "sku_yellow": sum(1 for r in kept_skus if r["quality"] == "yellow"),
        "sku_dropped": len([1 for kind, _ in dropped if kind == "sku"]),
        "inventory_rows": len(kept_inv),
        "sampled": sum(1 for r in kept_items if r["sampled"]),
        "pending": len([r for r in kept_items + kept_skus if r["review_status"] == "pending"]),
        "rule_hits": rule_hits,
        "pass_rate": (green / float(len(kept_items))) if kept_items else 0.0,
    }
    return {"items": kept_items, "skus": kept_skus, "inventory": kept_inv,
            "dropped": dropped, "anomalies": anomalies, "stats": stats}


# ------------------------------------------------------------
# quality.json
# ------------------------------------------------------------
def _ratio_stats(items):
    """列表价 vs 详情价偏差（plan §2.4c③）：算比值分布，不改数据。"""
    vals = [it["price_detail"] / it["price_list"]
            for it in items
            if (it.get("price_detail") or 0) > 0 and (it.get("price_list") or 0) > 0]
    if not vals:
        return {"n": 0, "mean": None, "std": None, "min": None, "max": None}
    mean = sum(vals) / float(len(vals))
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return {"n": len(vals), "mean": round(mean, 4),
            "std": round(math.sqrt(var), 4),
            "min": round(min(vals), 4), "max": round(max(vals), 4)}


def coverage(items):
    n = len(items) or 1
    checked = [r for r in items if r.get("image_ok") is not None]
    return {
        "detail_ratio": round(sum(1 for r in items if r.get("merge_status") != "list_only") / float(n), 4),
        "price_detail_ratio": round(sum(1 for r in items if r.get("price_detail") is not None) / float(n), 4),
        "price_complete_ratio": round(sum(1 for r in items if r.get("price_complete")) / float(n), 4),
        "sales_ratio": round(sum(1 for r in items if r.get("sales") is not None) / float(n), 4),
        # 只统计真正校验过的行；未启用图片校验时为 None（别显示成 0%）
        "image_ok_ratio": (round(sum(1 for r in checked if r.get("image_ok"))
                                / float(len(checked)), 4) if checked else None),
        "image_checked": len(checked),
    }


def build_report(date, stats, items, cfg, history=None, extra=None):
    return {
        "date": date,
        "counts": {k: stats[k] for k in (
            "item_total", "item_green", "item_yellow", "item_red",
            "sku_total", "sku_green", "sku_yellow", "sku_dropped",
            "inventory_rows", "sampled", "pending")},
        "pass_rate": round(stats.get("pass_rate", 0.0), 4),
        "rule_hits": stats.get("rule_hits") or {},
        "coverage": coverage(items),
        "list_detail_ratio": _ratio_stats(items),
        "history": history or {},
        "config": {"mad_k": cfg["mad_k"], "min_history": cfg["min_history"],
                   "spike_pct": cfg["spike_pct"], "sample_ratio": cfg["sample_ratio"],
                   "auto_pass_partial_min": cfg.get("auto_pass_partial_min")},
        "notes": [
            "红=禁入库；黄=保留待复核，复核前不进趋势；绿=auto_pass。",
            "SKU 行只放有价行；无价 SKU 在 inventory，不记 0 价。",
            "SKU 行的 price_complete=false 表示所属商品价不完整，不改变该行价格的可信性；"
            "趋势消费时按 price_complete 过滤。",
            "列表价只作触发器与偏差分析，不进趋势；趋势价取 price_detail。",
        ],
        "extra": extra or {},
    }


def _anomaly(row, rule, level, disposition, message):
    return {
        "crawl_date": row.get("crawl_date"),
        "product_id": row.get("product_id", ""),
        "sku_id": row.get("sku_id", ""),
        "level": level,
        "rule": rule,
        "message": message,
        "disposition": disposition,
        "source_file": row.get("source_file", ""),
        "crawl_ts": row.get("crawl_ts") or row.get("detail_ts") or row.get("list_ts") or "",
        "payload": {
            "title": row.get("title"),
            "price_list": row.get("price_list"),
            "price_detail": row.get("price_detail"),
            "price": row.get("price"),
            "price_raw": row.get("price_raw") or row.get("price_detail_raw") or row.get("price_list_raw"),
            "sales_raw": row.get("sales_raw"),
            "flags": row.get("flags"),
        },
    }
